import xbmcaddon

MainBase = 'http://onealliance.info/steventyler/hootloop/Example/home.txt'
addon = xbmcaddon.Addon('plugin.video.hootloop')